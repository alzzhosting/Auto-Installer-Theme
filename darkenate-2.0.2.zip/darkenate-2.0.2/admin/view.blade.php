<div class="row">
  <div class="col-xs-3">

    <!-- Overview -->
    <div class="box">
      <div class="box-header with-border">
        <h3 class="box-title"><i class='bx bx-command' style='margin-right:5px;'></i>Overview</h3>
      </div>
      <div class="box-body">
        <p>You are currently running version <code>{version}</code>.</p>
      </div>
    </div>

  </div>
</div>
